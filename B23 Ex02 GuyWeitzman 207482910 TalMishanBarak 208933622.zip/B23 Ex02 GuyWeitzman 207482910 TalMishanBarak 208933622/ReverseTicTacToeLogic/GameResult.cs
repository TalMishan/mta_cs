namespace ReverseTicTacToeLogic
{
    public enum eGameResult
    {  
        FirstCompetitorWin,
        SecondCompetitorWin,
        Draw,
        Ongoing,
    }
}