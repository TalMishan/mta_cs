namespace ReverseTicTacToeLogic
{
    public enum eGameType
    {
        Multiplayer,
        Singleplayer,
    }
}
