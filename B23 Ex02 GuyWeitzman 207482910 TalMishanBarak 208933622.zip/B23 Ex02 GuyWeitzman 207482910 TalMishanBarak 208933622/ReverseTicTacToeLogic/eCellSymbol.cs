namespace ReverseTicTacToeLogic
{
    public enum eCellSymbol
    {
        X,
        O,
        Empty,
    }
}
