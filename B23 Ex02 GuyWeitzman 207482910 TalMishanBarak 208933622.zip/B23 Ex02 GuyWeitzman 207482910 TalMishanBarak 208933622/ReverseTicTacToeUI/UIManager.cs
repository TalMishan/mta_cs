﻿using System.Text;
using ReverseTicTacToeLogic;

namespace ReverseTicTacToeUI
{
    public class UIManager
    {
        public static void Run()
        {
            bool isGameRoundEnds;
            bool gameNotOver = true;
            bool isNewGameRound = true;
            PrintWelcomeAndWarningMessage();// :)
            eGameType GameType = getGameTypeFromUser();
            int boardSize = getboardSizeFromUser();

            GameManager gameManager = new GameManager(GameType, boardSize);

            while (gameNotOver)
            {
                if (isNewGameRound)
                {
                    Ex02.ConsoleUtils.Screen.Clear();

                    gameManager.InitGame();
                    PrintBoard(gameManager.Board);
                    isNewGameRound = false;
                }

                if (playMove(gameManager) == false)
                {
                    Console.WriteLine("You quit the game");
                    isNewGameRound = true;
                    gameNotOver = askForAnotherRound();
                }

                Ex02.ConsoleUtils.Screen.Clear();
                PrintBoard(gameManager.Board);
                eGameResult currentStatus = gameManager.EvaluateGameResult(out isGameRoundEnds);
                if (currentStatus == eGameResult.Draw)
                {
                    Console.WriteLine("The game ended in a draw!");
                }
                else if (currentStatus == eGameResult.FirstCompetitorWin)
                {
                    Console.WriteLine($"{gameManager.FirstCompetitor.Symbol} won!");
                }
                else if (currentStatus == eGameResult.SecondCompetitorWin)
                {
                    Console.WriteLine($"{gameManager.SecondCompetitor.Symbol} won!");
                }

                if (isGameRoundEnds)
                {
                    Console.WriteLine($"Score:{Environment.NewLine}X wins: {gameManager.FirstCompetitor.Victories}{Environment.NewLine}O wins: {gameManager.SecondCompetitor.Victories}");
                    isNewGameRound = true;
                    gameNotOver = askForAnotherRound();
                }
            }
        }

        public static void PrintBoard(Board i_Board)
        {
            StringBuilder boardPrint = new StringBuilder();

            for (int i = 1; i <= i_Board.Size; i++)
            {
                boardPrint.Append($"  {i} ");
            }

            for (int i = 1; i <= i_Board.Size; i++)
            {
                boardPrint.Append($"{Environment.NewLine}{i}");
                for (int j = 0; j < i_Board.Size; j++)
                {
                    char symbol = ' ';
                    if (i_Board.GameBoard[i - 1, j] == eCellSymbol.X)
                    {
                        symbol = 'x';
                    }
                    else if (i_Board.GameBoard[i - 1, j] == eCellSymbol.O)
                    {
                        symbol = 'o';
                    }
                    boardPrint.Append($"| {symbol} ");
                }

                boardPrint.Append($"|{Environment.NewLine}==");
                for (int j = 0; j < i_Board.Size; j++)
                {
                    boardPrint.Append("====");
                }
            }
            Console.WriteLine(boardPrint);
        }

        private static eGameType getGameTypeFromUser()
        {
            string GameTypeStr;
            Console.WriteLine("In order to play against the computer press (1) or press any other key for multiplayer (2 competitors): ");
            GameTypeStr = Console.ReadLine();

            if (GameTypeStr.Equals("1"))
            {
                return eGameType.Singleplayer;
            }
            else
            {
                return eGameType.Multiplayer;
            }
        }

        private static int getboardSizeFromUser()
        {
            int boardSize;
            string boardSizeStr;

            Console.WriteLine("Please enter a board size between 3-9!");
            boardSizeStr = Console.ReadLine();
            while (int.TryParse(boardSizeStr, out boardSize) == false || GameManager.isValidBoardSize(boardSize) == false)
            {
                Console.WriteLine("Invalid board size!! Please enter a board size between 3-9!");
                boardSizeStr = Console.ReadLine();
            }
            return boardSize;
        }

        private static bool makeUserMove(GameManager i_GameManager)
        {
            string rowString, colString;
            int row = 0;
            int col = 0;
            bool quit = false;
            bool validCellChoice = false;

            Console.WriteLine($"Please choose an empty cell ({i_GameManager.CurrCompetitor.Symbol}):");

            while (!validCellChoice && !quit)
            {
                Console.WriteLine("Please enter a valid row:");
                rowString = Console.ReadLine();
                if (rowString == "Q")
                {
                    quit = true;
                    break;
                }

                while (!int.TryParse(rowString, out row) || !i_GameManager.Board.IsValidRowOrCol(row))
                {
                    Console.WriteLine("Please enter a valid row:");
                    rowString = Console.ReadLine();
                    if (rowString == "Q")
                    {
                        quit = true;
                        break;
                    }
                }

                if (quit)
                {
                    break;
                }

                Console.WriteLine("Please enter a valid column:");
                colString = Console.ReadLine();
                if (colString == "Q")
                {
                    quit = true;
                    break;
                }

                while (!int.TryParse(colString, out col) || !i_GameManager.Board.IsValidRowOrCol(col))
                {
                    Console.WriteLine("Please enter a valid column:");
                    colString = Console.ReadLine();
                    if (colString == "Q")
                    {
                        quit = true;
                        break;
                    }
                }

                if (quit)
                {
                    break;
                }

                if (i_GameManager.Board.IsEmptyCell(row - 1, col - 1))
                {
                    i_GameManager.Board.InsertSymbolToBoardCell(i_GameManager.CurrCompetitor.Symbol, row - 1, col - 1);
                    validCellChoice = true;
                }
                if (!validCellChoice)
                {
                    Console.WriteLine("Cell not empty! Please choose an empty cell:");
                }
            }
            return validCellChoice;
        }

        private static bool playMove(GameManager i_GameManager)
        {
            bool endedWithoutQuit = true;
            if (i_GameManager.GameType.Equals(eGameType.Singleplayer) && i_GameManager.CurrCompetitor == i_GameManager.SecondCompetitor)
            {
                i_GameManager.MakeRandomMove();
            }
            else
            {
                endedWithoutQuit = makeUserMove(i_GameManager);
            }

            i_GameManager.NextTurn();

            return endedWithoutQuit;
        }

        private static bool askForAnotherRound()
        {
            string userInput;
            bool playAnotherRound = false;

            Console.WriteLine("If you want to play another round, press Y for Yes or any other key to exit");
            userInput = Console.ReadLine();
            if (userInput.Equals("Y"))
            {
                playAnotherRound = true;
            }

            return playAnotherRound;
        }

        public static void PrintWelcomeAndWarningMessage()
        {
            string welcomeMessage = @"***********************************************************************************************
*                   .-----. _         .-----.             .-----.                             * 
*                   `-. .-':_;        `-. .-'             `-. .-'                             *
*                     : :  .-. .--.     : : .--.   .--.     : : .--.  .--.                    *
*                     : :  : :'  ..'    : :' .; ; '  ..'    : :' .; :' '_.' (REVERSE VERSION) *
*                     :_;  :_;`.__.'    :_;`.__,_;`.__.'    :_;`.__.'`.__.'                   *
*                                                                                             *
*                                                                                             *
*                                         WARNING!                                            *
*                                                                                             *
*                                  DANGER OF ADDICTION                                        *
*                          THE RESPONSIBILITY OF THE USER ONLY!                               *
*                                                                                             *
***********************************************************************************************
";
            Console.WriteLine(welcomeMessage);
        }
    }
}
