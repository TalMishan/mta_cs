﻿namespace ReverseTicTacToeUI
{
    public class Program
    {
        public static void Main()
        {
            UIManager.Run();
        }
    }
}